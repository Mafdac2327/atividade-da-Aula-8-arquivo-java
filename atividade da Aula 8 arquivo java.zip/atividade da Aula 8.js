const Saldo = 100;
alert(` Saldo${Saldo}  `);
let Valor_da_compra = prompt( 'Digite o Valor da Compra' );
let Valor_final;

if( Valor_da_compra <=Saldo ){
    Valor_final = Saldo - Valor_da_compra;
    alert(` Saldo final ${Valor_final} `);
}
else{
    alert(` Saldo insuficiente `);
}